const express = require('express');
const bodyParser = require('body-parser'); // incoming req body to the mw

const app = express();
const port = 4500;

// Middleware to serve static files from the 'public' directory
app.use(express.static('public'));

// Middleware to parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs');

let todos = [];

//define a route for handeling get req to root url
app.get('/', (req, res) => {
    res.render('index', { todos: todos });
});

//define route for handeling post request to root url
app.post('/', (req, res) => {
    const newTodo = req.body.newTodo;
    todos.push(newTodo);
    res.redirect('/');
});

// Route to handle deletion of a todo item
app.post('/delete/:index', (req, res) => {
    const index = req.params.index;
    todos.splice(index, 1); // Remove the todo item at the specified index
    res.redirect('/');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
